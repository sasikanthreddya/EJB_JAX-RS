package com.otml.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="REQUEST_PROCESS")
public class RequestProcess {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="REQUEST_NO")
	private int requestNo;
	@Column(name="DESCR")
	private String description;
	@Column(name="ASSIGN_DT")
	private Date assignDate;
	@Column(name="ETA")
	private Date eta;
	/*
	public RequestProcess(String description, Date assignDate, Date eta) {
		super();
		this.description = description;
		this.assignDate = assignDate;
		this.eta = eta;
	}*/
	public int getRequestNo() {
		return requestNo;
	}
	public void setRequestNo(int requestNo) {
		this.requestNo = requestNo;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getAssignDate() {
		return assignDate;
	}
	public void setAssignDate(Date assignDate) {
		this.assignDate = assignDate;
	}
	public Date getEta() {
		return eta;
	}
	public void setEta(Date eta) {
		this.eta = eta;
	}
	@Override
	public String toString() {
		return "RequestProcess [requestNo=" + requestNo + ", description="
				+ description + ", assignDate=" + assignDate + ", eta=" + eta
				+ "]";
	}
	

}
