package com.otml.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OrderColumn;
import javax.persistence.Table;
@Entity
@Table(name="TECHNICIAN")
public class Technician {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="TECH_NO")
	private int techinicianNo;
	@Column(name="TECH_NAME")
	private String name;
	@Column(name="DESIGNATION")
	private  String designation;
	@Column(name="CONTACT_NO")
	private  long contactNo;
	@Column(name="EMAIL_NO")
	private String emailNo;
	@OneToMany
	@JoinColumn(name = "TECH_NO")
	@OrderColumn(name = "TECH_REQPROCESS_NO")
	private List<RequestProcess> requestProcesses;
	
	/*public Technician(String name, String designation, long contactNo,
			String emailNo) {
		super();
		this.name = name;
		this.designation = designation;
		this.contactNo = contactNo;
		this.emailNo = emailNo;
	}*/
	@Override
	public String toString() {
		return "Technician [techinicianNo=" + techinicianNo + ", name=" + name
				+ ", designation=" + designation + ", contactNo=" + contactNo
				+ ", emailNo=" + emailNo + ", requestProcesses="
				+ requestProcesses + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}
	public int getTechinicianNo() {
		return techinicianNo;
	}
	public void setTechinicianNo(int techinicianNo) {
		this.techinicianNo = techinicianNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public long getContactNo() {
		return contactNo;
	}
	public void setContactNo(long contactNo) {
		this.contactNo = contactNo;
	}
	public String getEmailNo() {
		return emailNo;
	}
	public void setEmailNo(String emailNo) {
		this.emailNo = emailNo;
	}
	public List<RequestProcess> getRequestProcesses() {
		return requestProcesses;
	}
	public void setRequestProcesses(List<RequestProcess> requestProcesses) {
		this.requestProcesses = requestProcesses;
	}
	
	

}
